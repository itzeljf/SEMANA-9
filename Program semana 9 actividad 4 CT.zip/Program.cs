﻿internal class Program
{
    static void Main()
        {
            /*Console.Clear();
             */
            string[] aPalabras = { "HOLA", "Casa", "carro", "LAPIZ", "uno", "dos", "tres", "ocho", "nueve", "Diez" };
            string nombre = "ejemplo variable";

            for (int inc = 0; inc < 10; inc++)

            {
                Console.WriteLine("Validando mayusculas.. " + aPalabras[inc]);
            if (EsMayuscula(aPalabras[inc]))
                {
                    Console.WriteLine("La palabra: " + aPalabras[inc] + "es mayuscula. ");
                }
            }
        }
    
    static bool EsMayuscula(string input) 
        
    {
        for (int i = 0; 1 < input.Length; i++)
        {
            if (!Char.IsUpper(input[1]))
                return false;
        }
        return true;
    }
}